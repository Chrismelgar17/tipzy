# Apple Distribution Certificate Credentials

  Use these values in conjunction with your Apple Distribution Certificate files to distribute your iOS app to external users.

  ## Credential Values

  - Apple Distribution Certificate serial number: 4FBC3C70C631BDBEEF2652F7B5CC65FD
  - Apple Distribution Certificate password: cWapHiEKKqh4N3WMcxBl3Q==
  